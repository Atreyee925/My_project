import React from 'react'
import Scroll from "react-scroll-to-top";
export default function Scroll_to_top() {
    return (
      <div>
        <Scroll smooth />
      </div>
    );
  }